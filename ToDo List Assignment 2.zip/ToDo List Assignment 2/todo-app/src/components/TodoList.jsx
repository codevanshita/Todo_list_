import React, { useState, useEffect } from 'react';

const TodoList = () => {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState(() => {
    const saved = localStorage.getItem('tasks');
    return saved ? JSON.parse(saved) : [];
  });
  const [filter, setFilter] = useState('all');
  const [sortAsc, setSortAsc] = useState(true);

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

  const handleAddTask = () => {
    if (!task.trim()) return alert('Task cannot be empty');
    const newTask = { id: Date.now(), text: task.trim(), completed: false };
    setTasks([...tasks, newTask]);
    setTask('');
  };

  const handleDelete = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const toggleComplete = (id) => {
    setTasks(tasks.map(task => task.id === id ? { ...task, completed: !task.completed } : task));
  };

  const filteredTasks = tasks.filter(task =>
    filter === 'all' ? true :
    filter === 'completed' ? task.completed :
    !task.completed
  );

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    return sortAsc
      ? a.text.localeCompare(b.text)
      : b.text.localeCompare(a.text);
  });

  return (
  <div className="todo-container">
    <h1 className="todo-heading">To-Do List</h1>

    <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
      <input
        type="text"
        value={task}
        onChange={e => setTask(e.target.value)}
        placeholder="Enter new task"
        className="todo-input"
      />
      <button onClick={handleAddTask} className="todo-button">Add</button>
    </div>

    <div className="filter-sort">
      <select value={filter} onChange={e => setFilter(e.target.value)}>
        <option value="all" >All</option>
        <option value="active">Active</option>
        <option value="completed">Completed</option>
      </select>
      <button onClick={() => setSortAsc(!sortAsc)} className="sort-button">
        Sort {sortAsc ? 'A→Z' : 'Z→A'}
      </button>
    </div>

    <ul>
      {sortedTasks.map(({ id, text, completed }) => (
        <li key={id} className="todo-list-item">
          <span
            onClick={() => toggleComplete(id)}
            className={completed ? 'todo-completed' : ''}
            style={{ flex: 1, cursor: 'pointer' }}
          >
            {text}
          </span>
          <button onClick={() => handleDelete(id)} style={{ color: 'red' }}>❌</button>
        </li>
      ))}
    </ul>
  </div>
);
};

export default TodoList;
